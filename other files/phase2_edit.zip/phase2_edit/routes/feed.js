var express = require('express');
var router = express.Router();

router.get('/', (req, res) => {
    var data ={
        test: 'nooo'
    }
    res.render('feed', data);
});

module.exports = router;