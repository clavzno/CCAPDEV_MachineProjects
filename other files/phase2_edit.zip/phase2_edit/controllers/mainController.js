const mongoose = require('mongoose'); // Importing mongoose module



// Will continue




// module.exports = mainController;