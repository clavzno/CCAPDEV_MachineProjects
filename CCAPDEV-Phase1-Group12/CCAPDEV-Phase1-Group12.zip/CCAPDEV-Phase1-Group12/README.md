# CCAPDEV_MachineProjects
Created Feb 7, 2024
Started Feb 14, 2024

## TODO AFTER SUBMITTING MCO PHASE 1
- unify designs and improve common.css (fix inconsistencies in design)
- create templates for reused divs and buttons
- jquery, improve js + work on fetching data per profile
- implement bootstrap probably
- combine all sprites into one image using fontawesome (to save space)

## MEMBER DIVISIONS (GRP 12)
1. login/logout - Yazan Homssi
2. feed view - Gerome Ranigo
3. search view - Fred Garcia
4. profile view - Jack Clavano
